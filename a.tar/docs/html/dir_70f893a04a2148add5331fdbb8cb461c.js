var dir_70f893a04a2148add5331fdbb8cb461c =
[
    [ "debugger.c", "debugger_8c.html", null ],
    [ "debugger.h", "debugger_8h_source.html", null ]
];