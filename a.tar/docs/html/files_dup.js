var files_dup =
[
    [ "libs", "dir_6719ab1f1f7655efc2fa43f7eb574fd1.html", "dir_6719ab1f1f7655efc2fa43f7eb574fd1" ],
    [ "modules", "dir_e05d7e2b1ecd646af5bb94391405f3b5.html", "dir_e05d7e2b1ecd646af5bb94391405f3b5" ],
    [ "baseer.c", "baseer_8c.html", null ],
    [ "baseer.h", "baseer_8h.html", "baseer_8h" ]
];