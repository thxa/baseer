var indexSectionsWithContent =
{
  0: "bcdiu",
  1: "bciu",
  2: "bd"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files"
};

