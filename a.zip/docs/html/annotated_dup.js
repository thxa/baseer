var annotated_dup =
[
    [ "baseer_partition_t", "structbaseer__partition__t.html", null ],
    [ "baseer_target_t", "structbaseer__target__t.html", null ],
    [ "bparser", "structbparser.html", null ]
];