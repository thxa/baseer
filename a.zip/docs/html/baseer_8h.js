var baseer_8h =
[
    [ "baseer_partition_t", "structbaseer__partition__t.html", null ],
    [ "baseer_target_t", "structbaseer__target__t.html", null ]
];