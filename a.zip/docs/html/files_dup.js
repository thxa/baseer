var files_dup =
[
    [ "modules", "dir_e05d7e2b1ecd646af5bb94391405f3b5.html", "dir_e05d7e2b1ecd646af5bb94391405f3b5" ],
    [ "baseer.c", "baseer_8c.html", null ],
    [ "baseer.h", "baseer_8h.html", "baseer_8h" ]
];