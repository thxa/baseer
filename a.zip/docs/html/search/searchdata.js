var indexSectionsWithContent =
{
  0: "b",
  1: "b",
  2: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files"
};

