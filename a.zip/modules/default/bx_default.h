/**
 * @file bx_default.h
 * @brief default header file
 */
#ifndef BX_DEFAULT_H
#define BX_DEFAULT_H
#include <stdbool.h>

#include "../../baseer.h"

bool bx_default(baseer_target_t *target, unsigned int index, void *arg);
#endif
