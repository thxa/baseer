#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
int
main(int argc, char ** args)
{
   return 0;
}
